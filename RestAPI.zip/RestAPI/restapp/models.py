from django.db import models

# Create your models here.
class customer(models.Model):
    cus_name = models.CharField(max_length=30)
    cus_phone = models.IntegerField(default = 0)
    cus_email = models.EmailField()

    
