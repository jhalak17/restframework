
from django.urls import path, include
from .views import customer_list

urlpatterns = [
    path('customer/', customer_list)
]