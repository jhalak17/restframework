from django.contrib import admin
from .models import customer

# Register your models here.

class AdminCustomer(admin.ModelAdmin):
    list_display = ['cus_name', 'cus_phone', 'cus_email']

admin.site.register(customer, AdminCustomer)
